"""Helper functions for the pump selection notebook.

Model: Colebrook friction factor, Darcy-Weisbach head loss, system curve,
pump curves fitted from the manufacturer table, operating point, NPSH check
and energy cost.
"""
import json

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

G = 9.81
COLORS = {"Pump A": "#d95f02", "Pump B": "#1b9e77", "Pump C": "#7570b3"}
MARKERS = {"Pump A": ("s", 13, False), "Pump B": ("o", 8, True), "Pump C": ("o", 9, True)}


def load_inputs(csv_path="input 1 pump curves.csv", json_path="input 2 piping data.json"):
    curves = pd.read_csv(csv_path)
    with open(json_path) as f:
        piping = json.load(f)
    return curves, piping


def friction_factor(reynolds, diameter, roughness):
    """Colebrook equation solved by fixed point iteration."""
    f = 0.02
    for _ in range(60):
        f = (-2 * np.log10(roughness / diameter / 3.7 + 2.51 / (reynolds * np.sqrt(f)))) ** -2
    return f


def pipe_flow_state(flow_m3h, p):
    d = p["pipe_inner_diameter_m"]
    area = np.pi * d ** 2 / 4
    velocity = (flow_m3h / 3600) / area
    reynolds = p["density_kg_m3"] * velocity * d / p["viscosity_Pa_s"]
    f = friction_factor(reynolds, d, p["roughness_m"])
    return velocity, reynolds, f


def head_loss(flow_m3h, p, length, k_total):
    velocity, reynolds, f = pipe_flow_state(flow_m3h, p)
    d = p["pipe_inner_diameter_m"]
    friction = f * length / d * velocity ** 2 / (2 * G)
    fittings = k_total * velocity ** 2 / (2 * G)
    return friction, fittings


def system_head(flow_m3h, p):
    """Static head plus pipe friction, fittings and the heat exchanger loss."""
    length = p["discharge_length_m"] + p["suction_length_m"]
    k_total = p["discharge_fittings_K"] + p["suction_fittings_K"]
    friction, fittings = head_loss(flow_m3h, p, length, k_total)
    heat_exchanger = p["heat_exchanger_head_m_at_120_m3h"] * (flow_m3h / 120) ** 2
    return p["static_head_m"] + friction + fittings + heat_exchanger


def npsh_available(flow_m3h, p):
    suction_loss, suction_fittings = head_loss(
        flow_m3h, p, p["suction_length_m"], p["suction_fittings_K"])
    pressure_head = (p["atmospheric_pressure_Pa"] - p["vapor_pressure_Pa"]) / (
        p["density_kg_m3"] * G)
    return pressure_head - p["suction_lift_m"] - suction_loss - suction_fittings


def fit_pumps(curves):
    """Fit head, efficiency and NPSH required as quadratics of flow."""
    fits = {}
    for name, rows in curves.groupby("pump"):
        q = rows["flow_m3h"].to_numpy()
        eff = np.polyfit(q, rows["efficiency"], 2)
        fits[name] = {
            "head": np.polyfit(q, rows["head_m"], 2),
            "eff": eff,
            "npshr": np.polyfit(q, rows["npshr_m"], 2),
            "bep_flow": -eff[1] / (2 * eff[0]),
            "price": float(rows["purchase_price_usd"].iloc[0]),
        }
    return fits


def operating_point(fit, p):
    """Flow where pump head equals system head, found by bisection."""
    lo, hi = 20.0, 250.0
    gap = lambda q: np.polyval(fit["head"], q) - system_head(q, p)
    for _ in range(80):
        mid = (lo + hi) / 2
        if gap(lo) * gap(mid) <= 0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


def evaluate(curves, p, rate=None):
    """Operating point, NPSH check, energy and five year cost for each pump."""
    rate = p["electricity_usd_per_kwh"] if rate is None else rate
    rows = []
    for name, fit in fit_pumps(curves).items():
        q = operating_point(fit, p)
        head = np.polyval(fit["head"], q)
        eff = np.polyval(fit["eff"], q)
        power = p["density_kg_m3"] * G * (q / 3600) * head / eff / 1000
        npsha = npsh_available(q, p)
        npshr = np.polyval(fit["npshr"], q)
        energy = power * p["running_hours_per_year"] * rate
        rows.append({
            "Pump": name,
            "Flow (m3/h)": q,
            "Head (m)": head,
            "% of BEP flow": 100 * q / fit["bep_flow"],
            "Efficiency": eff,
            "Power (kW)": power,
            "NPSHa (m)": npsha,
            "NPSHr (m)": npshr,
            "NPSH margin (m)": npsha - npshr,
            "NPSH ratio": npsha / npshr,
            "Energy (USD/yr)": energy,
            "Price (USD)": fit["price"],
            "5 year cost (USD)": fit["price"] + 5 * energy,
        })
    table = pd.DataFrame(rows).set_index("Pump")
    table["Flow ok"] = table["Flow (m3/h)"] >= p["required_flow_m3h"]
    table["BEP ok"] = table["% of BEP flow"].between(70, 120)
    table["NPSH ok"] = (table["NPSH ratio"] >= 1.3) & (table["NPSH margin (m)"] >= 1.0)
    table["All pass"] = table["Flow ok"] & table["BEP ok"] & table["NPSH ok"]
    return table


def recommend(table):
    passing = table[table["All pass"]]
    return passing["5 year cost (USD)"].idxmin()


def plot_system_curve(p, path=None):
    flows = np.arange(20, 201, 20)
    plt.figure(figsize=(7, 4.5))
    plt.plot(flows, [system_head(q, p) for q in flows], "k-o", label="System curve")
    plt.axvline(p["required_flow_m3h"], color="grey", ls="--", label="Required flow")
    plt.xlabel("Flow (m3/h)")
    plt.ylabel("Head (m)")
    plt.title("System curve")
    plt.legend()
    plt.grid(alpha=0.3)
    if path:
        plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_pumps(curves, p, table, path=None):
    flows = np.arange(20, 201, 5)
    plt.figure(figsize=(8, 5))
    plt.plot(flows, [system_head(q, p) for q in flows], "k-", lw=2.5, label="System curve")
    for name, fit in fit_pumps(curves).items():
        plt.plot(flows, np.polyval(fit["head"], flows), color=COLORS[name], label=name)
        q = table.loc[name, "Flow (m3/h)"]
        marker, size, fill = MARKERS[name]
        plt.plot(q, table.loc[name, "Head (m)"], marker, color=COLORS[name], ms=size,
                 mfc=COLORS[name] if fill else "none", mew=2, zorder=5)
    plt.axvline(p["required_flow_m3h"], color="grey", ls="--", label="Required flow")
    plt.xlabel("Flow (m3/h)")
    plt.ylabel("Head (m)")
    plt.title("System curve and pump curves with operating points")
    plt.legend()
    plt.grid(alpha=0.3)
    if path:
        plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_npsh(curves, p, table):
    flows = np.arange(20, 201, 5)
    plt.figure(figsize=(8, 5))
    plt.plot(flows, [npsh_available(q, p) for q in flows], "k-", lw=2.5, label="NPSH available")
    for name, fit in fit_pumps(curves).items():
        plt.plot(flows, np.polyval(fit["npshr"], flows), color=COLORS[name],
                 label=f"{name} NPSH required")
        plt.plot(table.loc[name, "Flow (m3/h)"], table.loc[name, "NPSHr (m)"], "o",
                 color=COLORS[name], ms=9)
    plt.xlabel("Flow (m3/h)")
    plt.ylabel("NPSH (m)")
    plt.title("NPSH available against NPSH required")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


def save_table_image(table, path):
    show = table[["Flow (m3/h)", "% of BEP flow", "Efficiency", "Power (kW)",
                  "NPSH margin (m)", "NPSH ratio", "5 year cost (USD)", "All pass"]].copy()
    cells = []
    for _, r in show.iterrows():
        cells.append([f"{r['Flow (m3/h)']:.1f}", f"{r['% of BEP flow']:.0f}%",
                      f"{r['Efficiency']:.3f}", f"{r['Power (kW)']:.2f}",
                      f"{r['NPSH margin (m)']:.2f}", f"{r['NPSH ratio']:.2f}",
                      f"{r['5 year cost (USD)']:,.0f}", "Yes" if r["All pass"] else "No"])
    fig, ax = plt.subplots(figsize=(11, 2.4))
    ax.axis("off")
    tbl = ax.table(cellText=cells, rowLabels=list(show.index), colLabels=[
        "Flow m3/h", "% of BEP", "Efficiency", "Power kW", "NPSH margin m",
        "NPSH ratio", "5 yr cost USD", "Passes all"], loc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10)
    tbl.auto_set_column_width(list(range(8)))
    tbl.scale(1, 1.6)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
